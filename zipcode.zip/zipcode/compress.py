import zipfile

files = ["albrth.doc", "jesuh.doc", "andreh.doc"]
archive = "prueba2.zip"
password = b"12345"


#comprimir los archivos
with zipfile.ZipFile(archive, "w") as zf:
    for file in files:
        zf.write(file)

    zf.setpassword(password)

    #leer archivo creado zip 
    with zipfile.ZipFile(archive, "r") as zf:
        crc_test = zf.testzip()
        if crc_test is not None:
            print("Algo sucedio o Header incorrectos: {crc_test}")

    #Obtener informacion en la consola del zip creado 
    info = zf.infolist()
    print(info)

    file = info[0]
    with zf.open(file) as f:
        print(f.read().decode())
